#include <stdlib.h>
#include <math.h>
#include "simulation.h"

typedef struct sSimulation
{
  unsigned int NumStars;
  sStar** Stars;
} sSimulation;

sSimulation* createSimulation(unsigned int stars)
{
  sSimulation* ret = malloc(sizeof(sSimulation));
  ret->NumStars = stars;
  ret->Stars = malloc(sizeof(sStar*)*stars);
  float x =  .0f;
  float y =  .0f;
  float vx = .0f;
  float vy = .0f;
  float mass = .0f;
  float t = .0f;
  float u = .0f;
  float r = .0f;
  int halfHeight = HEIGHT/2;
  for(int i = 0; i < stars; i++)
  {
    // Create stars inside of a circle with a radius of height/2 pixels
    t = 2*3.14f*RandFloat(0.0f,1.0f);
    u = RandFloat(0.0f,1.0f) + RandFloat(0.0f,1.0f);
    r = (u>1) ? 2-u : u;
    x = 400 + (r*cos(t)*halfHeight);
    y = 300 + (r*sin(t)*halfHeight);
    vx = RandFloat(-1.0f, 1.0f);
    vy = RandFloat(-1.0f, 1.0f);
    mass = RandFloat(0.1f, 1.0f);
    ret->Stars[i] = createStar(x, y, vx, vy, mass);
  }
  return ret;
}

void destroySimulation(sSimulation* sim)
{
  // Sanity check.
  if(sim == NULL)
    return;
  // Free up all the memory used by the stars
  for(int i = 0; i < sim->NumStars; i++)
  {
    destroyStar(sim->Stars[i]);
  }
  // And free up the simulation itself.
  free(sim);
}

void calculateNextFrame(sSimulation* sim)
{
  // Sanity check.
  if(sim == NULL)
    return;
  int Stars = sim->NumStars;
  sStar* star = NULL;
  // For each star in the simulation, we need to calculate the force acted upon it by every other star in the simulation. 
  for(int i = 0; i < Stars; i++)
  {
    star = sim->Stars[i];
    // Reset the acceleration before recalculating it.
    star->aX = 0.0f;
    star->aY = 0.0f;
    for(int j = 0; j < Stars; j++)
    {
      // Make sure we're not trying to compare this star to itself.
      if(i != j)
      {
	// Use Newton's gravitational formula to calculate the force enacted upon this star by the relevant star being checked against.
	float fx = calculateHorizontalForce(star, sim->Stars[j]);
        float fy = calculateVerticalForce(star, sim->Stars[j]);
	// Calculate the acceleration using F = MA <=> F/M = A
	star->aX += (fx / (star->Mass * MAXMASS));
	star->aY += (fy / (star->Mass * MAXMASS));
      }
    }
  }
}

void updateSimulation(sSimulation* sim, float timeElapsed)
{
  if(sim == NULL)
    return;
  sStar* star = NULL;
  float t2 = timeElapsed * timeElapsed;
  for(int i = 0; i < sim->NumStars; i++)
  {
    star = sim->Stars[i];
    star->vX += (star->aX * timeElapsed);
    star->vY += (star->aY * timeElapsed);
    star->X += (star->vX*timeElapsed) + ((star->aX * t2) / 2);
    star->Y += (star->vY*timeElapsed) + ((star->aY * t2) / 2);

  }
}

void drawSimulation(sSimulation* sim, Uint32* Pixels)
{
  if(sim == NULL || Pixels == NULL)
    return;
  sStar* star = NULL;
  for(int i = 0; i < sim->NumStars; i++)
  {
    star = sim->Stars[i];
    drawStar(star, Pixels);
  }
}
